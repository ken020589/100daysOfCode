##!/usr/bin/env python
#day16 flask

from flask import Flask
from flask import render_template, url_for
app = Flask(__name__)

@app.route('/hello', methods=['GET', 'POST'])
def hello():
    return render_template('helloflask.html')

if __name__ == '__main__':
    app.run()